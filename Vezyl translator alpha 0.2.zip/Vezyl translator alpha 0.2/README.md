
# Vezyl Translator

The software provides the ability to translate into the desired language through popup when copying the text.


## Features

- Translate text directly on the screen via popup
- Translation window
- Auto start with window (may not working on alpha and beta version)


## Installation

Install Vezyl translator with .zip file

```bash
  Download the latest version of release, extract and run .exe file
```
    
## Authors

- [@vezyldicode](https://www.github.com/vezyldicode)

